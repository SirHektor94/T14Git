import { Component } from '@angular/core';

@Component({
  selector: 'app-feladat',
  templateUrl: './feladat.component.html',
  styleUrl: './feladat.component.css'
})
export class FeladatComponent {
  vizsgalandoSzam!:number;
  szamok:string [] = []
  
  szamVizsgalo():void{
    let vizsgaltSzam=this.vizsgalandoSzam;
    let oszto=0;
      for(let i=1;i<=vizsgaltSzam;i++){
	      if(vizsgaltSzam%i==0){
		      oszto++;
	      }     
      }
        
      if(oszto==2){
        this.szamok.push("A " +vizsgaltSzam +" prím");
      }
      else{
        this.szamok.push("A " +vizsgaltSzam +" NEM prím");
      }
  }
}
